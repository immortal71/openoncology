# OpenOncology README showcase source

Author: immortal71.

Install the pinned direct dependencies with `npm install`, then run `npm run studio`. `npm run video` exports MP4; `npm run gif` exports GIF. The initial still used for the loop reset is included in `public/`.

This is a presentation mockup using current demo fixture content from `web/lib/demo-data.ts`. It is not the running frontend and does not perform live analysis.

The workbench composition follows the inspected Hoppscotch README banner. The styled UI uses HeroUI 2.8.10 Listbox, Avatar, Chip, Tabs, Accordion, Breadcrumbs and Button. Run `npm run styles` after changing component classes. Cursor animation is adapted from RemotionUI revision 0aecaca2b61a167992e1205d10e4da16d8a71331. Upstream MIT notices are included under `src/vendor/`. There are no generated patient outcomes, live knowledge-base requests or new benchmark results.

Palette: Radix Slate + Blue. White/Slate surfaces, graphite text, Blue 12 circular rank markers, and an Amber off-label status pill. Rank 1/2/3 are ordinal positions in the existing demo; the numeric values are separate illustrative scores.
