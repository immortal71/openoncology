import React from "react";
import {Composition,registerRoot} from "remotion";
import {Showcase} from "./Showcase";
registerRoot(()=> <Composition id="Showcase" component={Showcase} durationInFrames={300} fps={30} width={1280} height={740}/>);
