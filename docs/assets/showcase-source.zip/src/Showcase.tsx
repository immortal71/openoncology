import React from 'react';
import {AbsoluteFill,Sequence,Img,staticFile,useCurrentFrame,interpolate} from 'remotion';
import {HeroUIProvider,Listbox,ListboxItem,Chip,Tabs,Tab,Accordion,AccordionItem,Avatar,Button,Breadcrumbs,BreadcrumbItem} from '@heroui/react';
import {Dna,Pill,FileText,Database,ArrowUpRight,AlertTriangle,ChevronRight,Download,Search,Plus,FlaskConical} from 'lucide-react';
import {CursorPath} from './vendor/remotion-ui/primitives/cursor-path';
import './hero-generated.css';
import './showcase.css';
const sources=['OncoKB','OpenTargets','DiffDock','ClinicalPhase'];
const candidates=[
 {name:'Sotorasib',score:'0.983',description:'Covalent KRAS G12C inhibitor',phase:'FDA approved'},
 {name:'Adagrasib',score:'0.973',description:'KRAS G12C inhibitor · CNS penetration',phase:'FDA approved'},
 {name:'Osimertinib',score:'0.710',description:'Different indication · not a validated match',phase:'Off-label'},
];
export const Showcase=()=>{
 const frame=useCurrentFrame(),second=frame>=156,index=second?1:0,drug=candidates[index],sourceTab=frame>=84&&frame<156;
 return <HeroUIProvider disableAnimation><AbsoluteFill className="showcase light text-foreground" style={{background:'#f0f0f3',padding:24,fontFamily:'Segoe UI,Arial,sans-serif'}}>
 <div className="workspace-shell">
  <header className="workspace-header"><div className="brand"><Dna size={25}/><strong>OpenOncology</strong></div><Breadcrumbs size="sm"><BreadcrumbItem>Demo workspace</BreadcrumbItem><BreadcrumbItem>KRAS G12C</BreadcrumbItem></Breadcrumbs><Chip size="sm" variant="flat" className="ml-auto">Demonstration data</Chip><Avatar name="OO" size="sm" classNames={{base:'bg-default-100 text-default-600',name:'text-xs'}}/></header>
  <div className="workspace-body">
   <aside className="case-sidebar">
    <div className="sidebar-heading">Workspace <Plus size={16}/></div><div className="search"><Search size={15}/>Find a case <span>⌘ K</span></div>
    <Listbox aria-label="Workspace navigation" variant="flat" selectedKeys={['drugs']} selectionMode="single" hideSelectedIcon classNames={{base:'p-0',list:'gap-1'}} itemClasses={{base:'px-3 py-2.5 rounded-xl',title:'text-sm'}}>
     <ListboxItem key="findings" startContent={<Dna size={17}/>}>Genomic findings</ListboxItem><ListboxItem key="drugs" startContent={<Pill size={17}/>} className="bg-primary-50 text-primary-900">Drug ranking</ListboxItem><ListboxItem key="report" startContent={<FileText size={17}/>}>Evidence report</ListboxItem>
    </Listbox>
    <div className="case-summary"><span className="small-label">Current case</span><h2>KRAS G12C</h2><p>Non-small cell<br/>lung cancer</p><Chip size="sm" variant="dot" color="primary">Demo case</Chip></div>
    <div className="findings"><span className="small-label">Genomic findings</span><div><span>KRAS</span><Chip size="sm" variant="flat">G12C</Chip></div><div><span>TP53</span><Chip size="sm" variant="flat">R175H</Chip></div></div>
    <div className="sidebar-footer"><FlaskConical size={16}/><span>Research prototype<br/>Expert review required</span></div>
   </aside>
   <main className="ranking-pane"><div className="ranking-heading"><div className="small-label">KRAS G12C</div><h1>Drug ranking</h1><p>Three candidates for evidence review</p></div><div className="list-label"><span>Candidate</span><span>Demo score</span></div>
    <Listbox aria-label="Ranked drug candidates" variant="flat" selectionMode="single" selectedKeys={[drug.name]} hideSelectedIcon classNames={{base:'p-0',list:'gap-2'}} itemClasses={{base:'rank-row rounded-2xl px-4 py-3',wrapper:'min-w-0',title:'whitespace-normal',description:'text-xs mt-1'}}>
     {candidates.map((c,i)=><ListboxItem key={c.name} textValue={`Rank ${i+1} ${c.name}`} className={c.name===drug.name?'bg-primary-50':''} startContent={<Avatar name={String(i+1)} classNames={{base:c.name===drug.name?'rank-avatar bg-primary text-white':'rank-avatar bg-default-100 text-default-600',name:'text-lg font-semibold'}}/>} endContent={<div className="score"><span>{c.score}</span><ChevronRight size={15}/></div>} description={<><span className="rank-description">{c.description}</span><Chip size="sm" variant="flat" color={i===2?'warning':'default'} className="mt-1">{c.phase}</Chip></>}><div className="rank-title"><span className="rank-word">Rank {i+1}</span><strong>{c.name}</strong></div></ListboxItem>)}
    </Listbox>
    <div className="ranking-note"><AlertTriangle size={17}/><p>Rank 3 is off-label for this context. Its position does not establish clinical suitability.</p></div><div className="ranking-footer">Illustrative demo scores, not response probabilities.</div>
   </main>
   <section className="evidence-pane"><div className="inspector-toolbar"><Chip variant="flat" color="primary" size="sm">Rank {index+1}</Chip><Button size="sm" variant="light" isIconOnly aria-label="Open report"><ArrowUpRight size={18}/></Button></div><h2>{drug.name}</h2><div className="drug-subtitle">KRAS G12C inhibitor</div><div className="status-line"><span className="status-dot"/>FDA approved<span>Demonstration output</span></div>
    <Tabs aria-label="Evidence details" selectedKey={sourceTab?'sources':'evidence'} variant="underlined" color="primary" classNames={{base:'w-full',tabList:'w-full gap-6 p-0 border-b border-divider',tab:'px-0 h-12 w-auto',tabContent:'text-sm',cursor:'w-full',panel:'pt-5'}}>
     <Tab key="evidence" title="Evidence"><Accordion selectedKeys={new Set(['mechanism','annotations'])} selectionMode="multiple" variant="light" className="px-0" itemClasses={{base:'px-0',trigger:'py-3',title:'text-sm font-semibold',content:'text-sm text-default-600 leading-relaxed pb-4',indicator:'text-default-400'}}>
      <AccordionItem key="mechanism" aria-label="Mechanism" title="Mechanism">{second?'Irreversible KRAS G12C inhibitor with CNS penetration.':'Covalent KRAS G12C inhibitor. Locks the protein in its inactive GDP-bound state.'}</AccordionItem>
      <AccordionItem key="annotations" aria-label="Source annotations" title="Source annotations"><div className="flex gap-2 flex-wrap">{sources.map(s=><Chip key={s} size="sm" variant="flat" startContent={<Database size={11}/>}>{s}</Chip>)}</div></AccordionItem>
     </Accordion><p className="review-note">Review against the patient’s diagnosis and treatment history.</p><Button color="primary" radius="full" size="sm" startContent={<Download size={15}/>}>Evidence report</Button></Tab>
     <Tab key="sources" title="Sources"><div className="source-list">{sources.map(s=><div key={s}><Database size={17}/><span>{s}</span><ArrowUpRight size={14}/></div>)}</div><p className="review-note">Annotations from the demo output. This preview does not retrieve live evidence.</p></Tab>
    </Tabs>
   </section>
  </div>
 </div>
 <footer className="presentation-caption"><span>Presentation mockup · current demo content</span><span>Illustrative scores · expert review required</span></footer>
 <Sequence from={20} durationInFrames={64} layout="none"><CursorPath points={[{x:1070,y:610},{x:873,y:313}]} durationInFrames={64} smoothing={.3} trail="none" clickAt={[1]} size={25} color="#113264"/></Sequence>
 <Sequence from={105} durationInFrames={51} layout="none"><CursorPath points={[{x:873,y:313},{x:487,y:451}]} durationInFrames={51} smoothing={.3} trail="none" clickAt={[1]} size={25} color="#113264"/></Sequence>
 {frame>=276&&<Img src={staticFile('showcase-first.png')} style={{position:'absolute',inset:0,width:'100%',height:'100%',opacity:interpolate(frame,[276,287],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}/>}
 </AbsoluteFill></HeroUIProvider>;
};

