const {heroui}=require('@heroui/react');
module.exports={content:['./src/Showcase.tsx','./node_modules/@heroui/**/dist/**/*.{js,ts,jsx,tsx}'],darkMode:'class',theme:{extend:{}},plugins:[heroui({themes:{light:{colors:{primary:{50:'#e6f4fe',100:'#d5efff',200:'#b2dfff',300:'#8ec8f6',400:'#5eb1ef',500:'#0d74ce',600:'#0d66b4',700:'#125aa0',800:'#154c85',900:'#113264',DEFAULT:'#113264',foreground:'#ffffff'}}}}})]};

